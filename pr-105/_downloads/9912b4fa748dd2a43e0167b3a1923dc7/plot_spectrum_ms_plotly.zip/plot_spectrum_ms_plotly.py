"""
Spectrum ms_plotly
=======================================

This example shows a spectrum.
We can add the ion_annotation and sequence annotation by specifying these columns.
"""

import pandas as pd
from io import StringIO
import requests

pd.options.plotting.backend = "ms_plotly"

# download the file for example plotting
url = (
    "https://github.com/OpenMS/pyopenms_viz/releases/download/v0.1.5/TestSpectrumDf.tsv"
)
headers = {"User-Agent": "Mozilla/5.0"}  # pretend to be a browser
try:
    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()  # Check for any HTTP errors
    df = pd.read_csv(StringIO(response.text), sep="\t")
except requests.RequestException as e:
    raise RuntimeError(f"Error downloading the file: {e}")

# mirror a reference spectrum with ion and sequence annoations
df.plot(
    x="mz",
    y="intensity",
    kind="spectrum",
    ion_annotation="ion_annotation",
    sequence_annotation="sequence",
)
